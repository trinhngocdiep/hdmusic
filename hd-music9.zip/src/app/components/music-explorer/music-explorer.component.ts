import { Component, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs/Subject';

import { AppService } from '../../services/app.service';
import { DataService } from '../../services/data.service';
import { ApiService } from '../../services/api.service';
import { EventBusService } from '../../services/event-bus.service';

@Component({
    selector: 'music-explorer',
    templateUrl: './music-explorer.component.html',
    styleUrls: ['./music-explorer.component.css']
})
export class MusicExplorerComponent {
    constructor(
        public dataService: DataService,
        public eventBus: EventBusService,
        public apiService: ApiService
    ){}

    @ViewChild('searchInput') searchInput;
    @ViewChild('contentTitle') contentTitle;

    state;
    player;
    storage;

    searchSuggestionsVisible;

    searching;
    autoLoading;

    private queries = new Subject<string>();

    ngOnInit() {
        this.loadState();
        this.initSearchBar();
        this.initContent();
        this.registerListeners();
    }

    private loadState() {
        this.player = this.dataService.player;
        this.state = this.dataService.state.explorer;
        if (!this.state) {
            this.state = this.dataService.state.explorer = {};
        }
        if (!this.state.query) {
            this.state.query = { yt: true, sc: false };
        }
        this.state.trendingVisible = !this.state.query.term;
    }

    private initSearchBar() {
        this.queries.debounceTime(500).distinctUntilChanged()
            .subscribe(term => {
                // stop suggestion if user already pressed "Enter" to search
                if (this.searching) {
                    return;
                }
                let searchTerm = (term || '').trim();
                if (searchTerm.length == 0) {
                    this.loadRecentSearches();
                    this.searchSuggestionsVisible = this.state.searchSuggestions.length > 0;
                    return;
                }

                // show suggestions
                this.apiService.suggest(searchTerm).subscribe(data => {
                    if (data && data.length > 0) {
                        this.state.searchSuggestions = data.map(e => {
                            return {value: e};
                        });
                        this.searchSuggestionsVisible = true;
                    }
                });
            });
    }

    private initContent() {
        if (!this.state.content || this.state.content.length == 0) {
            this.apiService.getHotTracks(this.state.query, this.state.offset)
                .subscribe(data => {
                    this.state.offset = data.offset;
                    this.state.content = data.tracks;
                });
        }
    }

    private registerListeners() {
        this.eventBus.onInitiated$.subscribe(initiated => {
            if (initiated) {
                let storage = this.dataService.storage;
                if (!storage.explorer) {
                    storage.explorer = {};
                }
                this.storage = storage.explorer;
                this.state.recentSearches = this.storage.recentSearches;
                this.loadRecentSearches();
            }
        });
    }

    search(term) {
        let searchTerm = (term || '').trim();
        this.searchSuggestionsVisible = false;
        this.state.trendingVisible = searchTerm.length == 0;
        this.state.query.term = searchTerm;
        this.state.offset = null;
        this.searching = true;

        //this.eventBus.loading(true);
        let searchResult;
        if (this.state.trendingVisible) {
            searchResult = this.apiService.getHotTracks(this.state.query, this.state.offset);
        } else {
            searchResult = this.apiService.search(this.state.query, this.state.offset);
        }
        searchResult
            .finally(() => {
                this.searching = false;
                //this.eventBus.loading(false);
            })
            .subscribe(data => {
                this.state.offset = data.offset;
                this.state.content = data.tracks;
                if (this.contentTitle) {
                    this.contentTitle.nativeElement.scrollIntoView();
                }
            });

        this.updateRecentSearches(searchTerm);
    }

    private loadRecentSearches() {
        this.state.recentSearches = this.state.recentSearches || [];
        this.state.recentSearches = this.state.recentSearches.filter(e => typeof e == 'string');
        this.state.searchSuggestions = this.state.recentSearches.map(e => {
            return {value: e, isHistory: true};
        });
    }

    private updateRecentSearches(searchTerm) {
        if (searchTerm && searchTerm.length > 0) {
            if (!this.state.recentSearches) {
                this.state.recentSearches = [];
            }
            // remove duplicates
            this.state.recentSearches = this.state.recentSearches.filter(e => e != searchTerm);

            // insert at the top
            this.state.recentSearches.unshift(searchTerm);

            // retain maximum 10 items
            if (this.state.recentSearches.length > 10) {
                this.state.recentSearches.slice(0, 9);
            }

            this.storage.recentSearches = this.state.recentSearches;
            console.debug('uploading recent searches to cloud storage', this.storage.recentSearches);
            this.dataService.syncStorage();

            this.loadRecentSearches();
        }

    }

    onSourceMenuItemClick(sourceName, event) {
        event.stopPropagation();
        this.state.query[sourceName] = !this.state.query[sourceName];
        this.search(this.state.query.term);
    }

    onSearchTextType() {
        this.queries.next(this.state.query.term);
    }

    onSearchTextFocus() {
        if (this.state.searchSuggestions && this.state.searchSuggestions.length > 0) {
            this.searchSuggestionsVisible = true;
        }
    }

    onSearchTextBlur() {
        setTimeout(() => this.searchSuggestionsVisible = false, 300);
    }

    onSearchTextEnter() {
        let selectedSuggestion = this.state.searchSuggestions && this.state.searchSuggestions.find(e => e.active);
        if (selectedSuggestion){
            this.state.query.term = selectedSuggestion.value;
        }
        this.search(this.state.query.term);
    }

    onSearchTextEsc() {
        this.searchSuggestionsVisible = false;
        this.searchInput.nativeElement.blur();
    }

    onSearchTextArrowDown($event) {
        let suggestions = this.state.searchSuggestions;
        if (suggestions && suggestions.length > 0) {
            let currentIndex = suggestions.findIndex((e) => e.active);
            if (currentIndex >= 0) {
                suggestions[currentIndex].active = false;
            }
            let nextIndex = currentIndex + 1;
            if (nextIndex >= suggestions.length) {
                nextIndex = 0;
            }
            suggestions[nextIndex].active = true;

            $event.stopPropagation();
        }
    }

    onSearchTextArrowUp($event) {
        let suggestions = this.state.searchSuggestions;
        if (suggestions && suggestions.length > 0) {
            let currentIndex = suggestions.findIndex((e) => e.active);
            if (currentIndex >= 0) {
                suggestions[currentIndex].active = false;
            }
            let prevIndex = currentIndex - 1;
            if (prevIndex < 0) {
                prevIndex = suggestions.length - 1;
            }
            suggestions[prevIndex].active = true;

            $event.stopPropagation();
        }
    }

    onSearchSuggestionsHover() {
        this.state.searchSuggestions.forEach(e => e.active = false);
    }

    onScroll($event) {
        if ($event.target.scrollTop + $event.target.clientHeight + 20 >= $event.target.scrollHeight) {
            if (this.autoLoading) {
                return;
            }

            let searchResult;
            if (this.state.trendingVisible) {
                searchResult = this.apiService.getHotTracks(this.state.query, this.state.offset);
            } else {
                searchResult = this.apiService.search(this.state.query, this.state.offset);
            }
            this.autoLoading = true;
            //this.eventBus.loading(true);
            searchResult
                .finally(() => {
                    this.autoLoading = false;
                    //this.eventBus.loading(false);
                })
                .subscribe(data => {
                    this.state.offset = data.offset;
                    Array.prototype.push.apply(this.state.content, data.tracks);
                });
        }
    }

    addToLib(item) {
        this.eventBus.addToLib(item, true);
    }

    goToOrigin(item) {
        AppService.openBrowserTab(item.sourceUrl);
    }

    play(item) {
        this.eventBus.play(item);
        this.eventBus.addToLib(item, false);
    }

    pause() {
        this.eventBus.stop();
    }

    queue(item) {
        this.eventBus.queue(item);
        this.eventBus.addToLib(item, false);
    }

}