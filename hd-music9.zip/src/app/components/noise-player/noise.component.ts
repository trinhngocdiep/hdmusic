import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../../services/data.service';

declare var Hls;

@Component({
    selector: 'noise',
    template: `
    <span class="noise" [class.noise_selected]="selected" [title]="data.title" (click)="toggleSelection()">
        <img class="noise__icon" [src]="data.icon">
        <mat-slider class="noise__volume" min="0" max="100" [value]="volume" (click)="$event.stopPropagation()" (change)="setVolume($event.value);"></mat-slider>
    </span>
    `,
    styleUrls: ['./noise.component.css']
})
export class NoiseComponent {

    constructor(
        private dataService: DataService
    ) { }

    @Input() data;
    @Output() select = new EventEmitter();

    selected = false;
    volume = 30;

    private noisePlayer = this.dataService.noisePlayer;

    ngOnInit() {
        let player = this.noisePlayer.getPlayer(this.data);
        if (player) {
            this.volume = player.video.volume * 100;
            this.selected = player.enabled;
            this.select.emit();
        }
    }

    toggleSelection() {
        this.selected = !this.selected;
        if (this.selected) {
            this.play();
            this.setVolume(this.volume);
            this.select.emit();
        } else {
            this.stop();
        }
    }

    setVolume(value) {
        this.noisePlayer.setVolume(this.data, value / 100);
    }

    play() {
        this.noisePlayer.play(this.data);
    }

    stop() {
        this.noisePlayer.stop(this.data);
    }

    setPaused(paused) {
        if (!this.selected) {
            return;
        }
        paused ? this.stop() : this.play();
    }

}
