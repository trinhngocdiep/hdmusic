import { Component, ViewChildren } from '@angular/core';
import { NoiseComponent } from './noise.component';

@Component({
    selector: 'noise-player',
    template: `
    <div class="container">
        <div class="container__controls">
            <span class="container__controls-hint">Select to mix the noises</span>
            <i *ngIf="!muted" class="container__controls-mute material-icons" (click)="toggleMuted()">volume_up</i>
            <i *ngIf="muted" class="container__controls-mute material-icons" (click)="toggleMuted()">volume_off</i>
        </div>
        <div class="container__noises">
            <noise *ngFor="let e of noises" [data]="e" (select)="noiseSelected()"></noise>
        </div>
    </div>
    `,
    styleUrls: ['./noise-player.component.css']
})
export class NoisePlayerComponent {

    @ViewChildren(NoiseComponent) noisePlayers;

    muted: boolean;
    noises = [
        { icon: 'assets/images/sea-waves.svg', title: 'Sea Side', source: 'https://cdn.noisli.com/hls/seaside/seaside.m3u8' },
        { icon: 'assets/images/forest.svg', title: 'Forest', source: 'https://cdn.noisli.com/hls/forest/forest.m3u8' },
        { icon: 'assets/images/rain.svg', title: 'Rain', source: 'https://cdn.noisli.com/hls/rain/rain.m3u8' },
        { icon: 'assets/images/thunder.svg', title: 'Thunder Storm', source: 'https://cdn.noisli.com/hls/thunderstorm/thunderstorm.m3u8' },
        { icon: 'assets/images/fire.svg', title: 'Fire', source: 'https://cdn.noisli.com/hls/fire/fire.m3u8' },
        { icon: 'assets/images/night.svg', title: 'Summer Night', source: 'https://cdn.noisli.com/hls/summernight/summernight.m3u8' },
        { icon: 'assets/images/wind.svg', title: 'Wind', source: 'https://cdn.noisli.com/hls/wind/wind.m3u8' },
        { icon: 'assets/images/leaves.svg', title: 'Leaves', source: 'https://cdn.noisli.com/hls/leaves/leaves.m3u8' },
    ];

    toggleMuted() {
        this.muted = !this.muted;
        this.noisePlayers.forEach(e => e.setPaused(this.muted));
    }

    noiseSelected() {
        if (this.muted) {
            this.toggleMuted();
        }
    }
}
