import { Component, NgZone, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { AppService } from '../../services/app.service';
import { ApiService } from '../../services/api.service';
import { DataService } from '../../services/data.service';
import { EventBusService } from '../../services/event-bus.service';

@Component({
    selector: 'now-playing',
    templateUrl: './now-playing.component.html',
    styleUrls: ['./now-playing.component.css']
})
export class NowPlayingComponent {
    constructor(
        private ngZone: NgZone,
        public snackBar: MatSnackBar,
        public dataService: DataService,
        public eventBus: EventBusService,
        public apiService: ApiService
    ){}

    @ViewChild('progress') progress;

    player;

    ngOnInit() {
        this.loadBackgroundPlayer();
        this.registerListeners();
    }

    ngAfterViewInit() {
        if (!this.player.tracks || this.player.tracks.length <= 0) {
            this.eventBus.navigate(2);
        }
    }

    private loadBackgroundPlayer() {
        this.player = this.dataService.player;
        this.player.tracks = this.player.tracks || [];
        this.player.onPlay = () => {
            console.debug('onPlay');
            this.ngZone.run(() => {
                this.player.playing = true;
                // reset progress
                if (this.progress) {
                    this.progress.min = -1;
                    this.progress.max = 0;
                    this.progress.value = -1;
                }
                this.eventBus.addToLib(this.player.currentTrack, false);
            });
        };
        this.player.onPause = () => {
            console.debug('onPause');
            this.ngZone.run(() => {
                this.player.playing = false;
            });
        };
        this.player.onProgress = (track, currentTime) => {
            console.debug('onProgress', currentTime);
            this.ngZone.run(() => {

                this.player.playing = true;

                // update progress bar's max and initial value
                if (this.progress && track.durationInSeconds) {
                    this.progress.max = track.durationInSeconds;
                    this.progress.value = currentTime;
                }
            });
        };
        this.player.onEnd = () => {
            console.debug('onEnd');
            this.ngZone.run(() => {
                this.player.playing = false;
            });
        };
        this.player.onError = (error) => {
            this.ngZone.run(() => {
                this.player.playing = false;
                this.snackBar.open(error || 'Cannot play track', null, {duration: 3000});
            });
        };
    }

    private registerListeners() {
        this.eventBus.onPlay$.subscribe(data => {
            if (!data || !data.track) {
                return;
            }
            let track = data.track;
            if (!track.title || !track.sourceUrl) {
                return;
            }
            let tracks = data.tracks;
            if (!tracks || tracks.length == 0) {
                tracks = [track];
            }
            this.player.play(track);
            this.player.tracks = tracks;
            this.ngZone.run(() => {
                this.snackBar.open('Playing', null, {duration: 3000});
            });
        });

        this.eventBus.onStop$.subscribe(stop => {
            if (stop) {
                console.debug('player stop event');
                this.player.pause();
            }
        });

        this.eventBus.onQueue$.subscribe(track => {
            if (track) {
                this.player.tracks.push(track);
                this.ngZone.run(() => {
                    this.snackBar.open('Added to playing queue', null, {duration: 3000});
                });
            }
        });
    }

    play(track) {
        if (this.player.playing && this.player.currentTrack && this.player.currentTrack.sourceUrl == track.sourceUrl) {
            return;
        }
        if (this.player.currentTrack && this.player.currentTrack.sourceUrl == track.sourceUrl) {
            this.player.resume();
        } else {
            this.player.play(track, this.player.tracks);
        }
    }

    seek(time) {
        this.player.seek(time);
    }

    playAll() {
        this.eventBus.playLib();
    }

    goToLib() {
        this.eventBus.navigate(1);
    }

    goToExplore() {
        this.eventBus.navigate(2);
    }

    goToNoises() {
        this.eventBus.navigate(3);
    }

    goToOrigin(item) {
        AppService.openBrowserTab(item.sourceUrl);
    }

    download(item) {
        let timeout = setTimeout(() => this.eventBus.loading(true), 300);
        this.apiService.getDownloadLink(item)
            .finally(() => {
                clearTimeout(timeout);
                this.eventBus.loading(false);
            })
            .subscribe(result => {
                if (result) {
                    AppService.download(result);
                }
            }, error => {
                this.snackBar.open('Download not available', null, {duration: 3000});
            });
    }

    findRelatedTracks(item) {
        // first, populate the list with the selected item and then play it.
        this.player.tracks = [item];
        this.play(item);

        // populate the list with related items when they become available.
        this.apiService.getRelatedTracks(item).subscribe(data => {
            if (data.tracks.length > 0) {
                this.player.tracks = this.player.tracks.concat(data.tracks);
                this.play(item);
            }
        });
    }
}