import { Injectable } from '@angular/core';

declare var chrome;
declare var background;

@Injectable()
export class AppService {

    static getBackground() {
        if (chrome.extension) {
            return chrome.extension.getBackgroundPage().background;
        }
        return background;
    }

    static openBrowserTab(url) {
        if (!url) {
            return;
        }
        if (chrome.extension) {
            chrome.tabs.create({url: url});
        } else {
            window.open(url, '_blank');
        }
    }

    static download(result) {
        if (chrome && chrome.downloads) {
            chrome.downloads.download(result);
        } else {
            window.open(result.url, '_blank');
        }
    }
}