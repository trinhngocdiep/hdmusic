import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

declare var chrome;

import { EventBusService } from './event-bus.service';
import { AppService } from './app.service';

@Injectable()
export class DataService {

    constructor(
        private eventBus: EventBusService
    ) {
        this.initialize();
    }

    // background music player
    player: any;
    noisePlayer: any;

    // local state for data sync between background and ui
    state: any;

    // cloud storage for data sync between devices
    storage: any;

    syncStorage() {
        this.storage.sync();
    }

    private initialize() {
        let background = AppService.getBackground();
        this.player = background.player;
        this.noisePlayer = background.noisePlayer;
        this.state = background.state;
        if (background.ready) {
            this.storage = background.storage;
            this.eventBus.initiated();
        }
        background.onReady = () => {
            this.storage = background.storage;
            this.eventBus.initiated();
        };

        if (chrome && chrome.runtime && chrome.runtime.onMessage) {
            chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
                if (request.msg === 'playall') {
                    this.eventBus.playLib();
                }
            })
        }
    }

}