import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/merge';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

const SC_KEY = '458dac111e2456c40805cd838f4548c1'; // KyZEBUaphfHpKKZ9B0H9JsmvDULUPAkj
const YT_KEY = 'AIzaSyDGbUJxAkFnaJqlTD4NwDmzWxXAk55gFh4';

@Injectable()
export class ApiService {

    constructor(
        private http: Http
    ) {}

    suggest(term: string) {
        return this.http.get('https://suggestqueries.google.com/complete/search?hl=en&client=firefox&q=' + term).map(data => data.json()[1]);
    }

    getHotTracks(query, offset) {
        console.debug('getHotTracks', query);
        let scQuery;
        if (query.sc) {
            scQuery = 'https://api-v2.soundcloud.com/charts?kind=top&genre=soundcloud:genres:all-music&client_id=' + SC_KEY;
        }
        let ytQuery;
        if (query.yt) {
            ytQuery = 'https://www.googleapis.com/youtube/v3/videos?part=id&chart=mostPopular&maxResults=10&key=' + YT_KEY;
        }
        return this._search(scQuery, ytQuery, offset);
    }

    getRelatedTracks(track) {
        if (!track.videoId) {
            console.log('Cannot find related video for non-youtube track', track);
            return Observable.of({tracks: [], pageToken: null});
        }
        let findRelatedQuery = 'https://www.googleapis.com/youtube/v3/search?key=' + YT_KEY + '&maxResults=50&type=video&part=snippet&relatedToVideoId=' + track.videoId;
        return this._searchYt(findRelatedQuery, null);
    }

    search(query, offset) {
        console.debug('search', query);
        let scQuery;
        if (query.sc) {
            scQuery = 'https://api.soundcloud.com/tracks?linked_partitioning=1&limit=10&client_id=' + SC_KEY + '&q=' + query.term;
        }
        let ytQuery;
        if (query.yt) {
            ytQuery = 'https://www.googleapis.com/youtube/v3/search?key=' + YT_KEY + '&part=id&type=video,playlist&maxResults=10&q=' + query.term;
        }
        return this._search(scQuery, ytQuery, offset);
    }

    getDownloadLink(track): Observable<any> {
        if (track && track.videoId) {
            return this.http.get('https://www.youtube.com/get_video_info?video_id=' + track.videoId)
                .map(result => {
                    let data = decodeURIComponent(result.text()).split('&url_encoded_fmt_stream_map=')[1];
                    let firstUrl = data.split('url=')[1].split('&itag')[0];
                    return {url: decodeURIComponent(firstUrl), filename: sanitizeFileName(track.title) + '.mp4'};
                });
        }
        if (track && track.stream_url) {
            return Observable.of({url: track.stream_url, filename: sanitizeFileName(track.title) + '.mp3'});
        }
        return Observable.throw('Download not supported:. Track info: ' + JSON.stringify(track));

        function sanitizeFileName(name) {
            return name.replace(/[^a-zA-Z0-9-_\.]/g, '_');
        }
    }

    private _search(scQuery, ytQuery, offset) {
        let scSearchResult = this._searchSc(scQuery, offset);
        let ytSearchResult = this._searchYt(ytQuery, offset);
        return Observable.forkJoin(scSearchResult, ytSearchResult)
            .map(data => {
                return {
                    tracks: data[0].tracks.concat(data[1].tracks),
                    offset: {
                        next_href: data[0].next_href,
                        pageToken: data[1].pageToken
                    }
                }
            });
    }

    private _searchSc(scSearchQuery, offset) {
        if (offset) {
            // fetch next page
            if (offset.next_href) {
                scSearchQuery = offset.next_href;
            } else {
                // no more result
                scSearchQuery = null;
            }
        }
        if (!scSearchQuery) {
            return Observable.of({tracks: [], next_href: null});
        }

        return this.http.get(scSearchQuery).map(response => {
            let data = response.json();
            let tracks = data.collection
                .map(e => {
                    if (e.track) {
                        // for top tracks query
                        return e.track;
                    }
                    return e;
                })
                .filter(e => e.streamable)
                .map(e => {
                    let durationInSeconds = e.duration / 1000;
                    return {
                        title: e.title.replace(/[^\x00-\x7F]/g, ''), // remove non-ASCII characters
                        durationInSeconds: durationInSeconds,
                        artwork_url: e.artwork_url,
                        stream_url: e.uri + '/stream?client_id=' + SC_KEY,
                        source: 'sc',
                        sourceUrl: e.permalink_url
                    };
                });
            let nextPage = data.next_href;
            if (nextPage && nextPage.indexOf('&client_id=') < 0) {
                console.debug('appending client_id to nextPage');
                nextPage = nextPage + '&client_id=' + SC_KEY;
            }
            return {
                tracks: tracks,
                next_href: nextPage
            }
        });
    }

    private _searchYt(ytSearchQuery, offset) {
        if (offset) {
            // fetch next page
            if (offset.pageToken) {
                ytSearchQuery += '&pageToken=' + offset.pageToken;
            } else {
                // no more result
                ytSearchQuery = null;
            }
        }
        if (!ytSearchQuery) {
            return Observable.of({tracks: [], pageToken: null});
        }
        let nextPageToken;

        // search youtube videos and playlists
        return this.http.get(ytSearchQuery)
            .map(response => {
                let data = response.json();
                nextPageToken = data.nextPageToken;
                return data.items.map(e => {
                    return {
                        videoId: e.id.videoId || e.id,
                        playlistId: e.id.playlistId
                    }
                });
            })
            .flatMap(ids => {
                // get videos info
                let videoIds = ids.map(e => e.videoId).filter(e => !!e);
                let videos = Observable.of([]);
                if (videoIds.length > 0) {
                    videos = this.http.get('https://www.googleapis.com/youtube/v3/videos?key=' + YT_KEY + '&part=snippet,contentDetails,status&id=' + videoIds.join(','))
                        .map(response => {
                            return response.json().items.filter(e => e.status.embeddable).map(e => {
                                let durationInSeconds = isoDurationToSeconds(e.contentDetails.duration);
                                return {
                                    videoId: e.id,
                                    title: e.snippet.title,
                                    durationInSeconds: durationInSeconds,
                                    artwork_url: e.snippet.thumbnails.default.url,
                                    source: 'yt',
                                    sourceUrl: 'https://youtube.com/watch?v=' + e.id
                                };
                            });
                        });
                }

                // get playlists info
                let playlistIds = ids.map(e => e.playlistId).filter(e => !!e);
                let playlists = Observable.of([]);
                if (playlistIds.length > 0) {
                    playlists = this.http.get('https://www.googleapis.com/youtube/v3/playlists?key=' + YT_KEY + '&part=snippet&id=' + playlistIds.join(','))
                        .map(response => {
                            return response.json().items.map(e => {
                                return {
                                    title: e.snippet.title,
                                    artwork_url: e.snippet.thumbnails.default.url,
                                    playlistId: e.id,
                                    source: 'yt',
                                    sourceUrl: 'https://www.youtube.com/results?search_query=' + e.id
                                };
                            });
                        });
                        //// get playlist url
                        //.flatMap(playlists => {
                        //    this.http.get('https://www.googleapis.com/youtube/v3/playlistItems?key=' + YT_KEY + '&part=contentDetails&playlistId=' + playlistIds.join(','))
                        //})
                }

                return Observable.forkJoin(videos, playlists)
                    .map(data => {
                        return {
                            tracks: data[0].concat(data[1]),
                            pageToken: nextPageToken
                        }
                    });
            });
    }

}

export function isoDurationToSeconds(value: string) {
    var reptms = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/;
    var hours = 0, minutes = 0, seconds = 0;

    if (reptms.test(value)) {
        var matches = reptms.exec(value);
        if (matches[1]) hours = Number(matches[1]);
        if (matches[2]) minutes = Number(matches[2]);
        if (matches[3]) seconds = Number(matches[3]);
        return hours * 3600  + minutes * 60 + seconds;
    }
    return 0;
}