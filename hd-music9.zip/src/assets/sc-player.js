class ScPlayer {
    constructor() {
        this.audio = new Audio();
        this.audio.ontimeupdate = () => {
            this.onProgress && this.onProgress(this.audio.currentTime);
        };
        this.audio.onpause = () => {
            this.onPause && this.onPause();
            if (this.audio.ended) {
                this.onEnd && this.onEnd();
            }
        };
    }

    canPlay(track) {
        return !!track.stream_url;
    }

    play(track) {
        if (!this.canPlay(track)) {
            return;
        }
        this.audio.src = track.stream_url;
        this.audio.play();
        this.onPlay && this.onPlay();
    }

    resume(track) {
        if (!this.canPlay(track)) {
            return;
        }
        if (this.audio.src == track.stream_url) {
            this.audio.play();
            this.onPlay && this.onPlay();
        }
    }

    pause() {
        this.audio.pause();
    }

    seek(time) {
        this.audio.currentTime = time;
        if (this.audio.paused) {
            this.audio.play();
        }
    }

    setVolume(volume) {
        this.audio.volume = volume;
    };
}