class YtPlayer {

    constructor() {
        this._init();
    }

    _init() {
        const PROXY_URL = 'https://hdmusic.neocities.org';
        window.onload = () => {
            console.debug('creating proxy', PROXY_URL);
            let iframe = document.createElement('iframe');
            iframe.width = '100%';
            iframe.height = '500';
            iframe.src = PROXY_URL;
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            this.proxy = iframe.contentWindow;
        };

        window.addEventListener('message', (message) => {
            console.debug('background player received message', message);
            let origin = message.origin;
            let data = message.data;
            // ignore messages from youtube iframe
            if (origin != PROXY_URL) {
                return;
            }
            // dispatch messages from our proxy page
            this._dispatch(message.data.event, message.data.data);
        });
    }

    _dispatch(event, data) {
        switch (event) {
            case 'onPlay': {
                this.onPlay && this.onPlay();
                break;
            }
            case 'onPause': {
                this.onPause && this.onPause();
                break;
            }
            case 'onEnd': {
                this.onEnd && this.onEnd();
                break;
            }
            case 'onError': {
                this.onError && this.onError(data);
                break;
            }
            case 'onProgress': {
                this.onProgress && this.onProgress(data);
                break;
            }
        }
    }

    _postMessageToProxy(message) {
        if (!this.proxy) {
            console.log('Proxy window is not ready');
            this.onError && this.onError('Player is not ready');
            return;
        }
        this.proxy.postMessage(message, '*');
    }

    canPlay(track) {
        return !!track.videoId || !!track.playlistId;
    }

    play(track) {
        this._postMessageToProxy({ command: 'play', data: track });
    }

    resume(track) {
        this._postMessageToProxy({ command: 'resume', data: track });
    }

    pause() {
        this._postMessageToProxy({ command: 'pause' });
    }

    seek(time) {
        this._postMessageToProxy({ command: 'seek', data: time });
    }

    setVolume(volume) {
        this._postMessageToProxy({ command: 'setVolume', data: volume });
    }

}