class UserStorage {

    constructor() {
        this.cloudStorageApiUrl = 'https://api.myjson.com/bins/';
        this.baseBucketId = '9hoin';
        this.userBucketId = null;
        this.userBucket = null;
    }

    init(callback) {
        this._getUserId(userId => this._loadCloudStorage(userId, callback));
        setInterval(() => {
            console.debug('auto sync');
            //this.sync();
        }, 10000);
    }

    sync() {
        if (!this.userBucket || !this.userBucketId) {
            console.debug('cloud storage not available');
            return;
        }
        let url = this.cloudStorageApiUrl + this.userBucketId;
        _ajax(url, 'PUT', this.userBucket)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error(response.status);
            });
    }

    _getUserId(callback) {
        const defaultUserId = 'hd-music';
        if (!chrome || !chrome.identity) {
            callback(defaultUserId);
            return;
        }
        chrome.identity.getProfileUserInfo((userInfo) => callback(userInfo && userInfo.id || defaultUserId));
    }

    _loadCloudStorage(userId, callback) {
        _ajax(this.cloudStorageApiUrl + this.baseBucketId)
            .then(response => response.json())
            .then(buckets => {
                let bucketId = buckets[userId];
                if (bucketId) {
                    _ajax(this.cloudStorageApiUrl + bucketId)
                        .then(response => {
                            if (response.ok) {
                                return response.json();
                            }
                            throw new Error(response.status);
                        })
                        .then(data => {
                            this.userBucket = data;
                            this.userBucketId = bucketId;
                            callback();
                        })
                        .catch(error => console.log('error getting buckets for user', bucketId, error));
                    return;
                }

                this.userBucket = {id: userId};
                _ajax(this.cloudStorageApiUrl, 'POST', this.userBucket)
                    .then(response => {
                        if (response.ok) {
                            return response.json();
                        }
                        throw new Error(response.status);
                    }).then(data => {
                        this.userBucketId = data.uri;
                        buckets[userId] = this.userBucketId;
                        _ajax(this.cloudStorageApiUrl + this.baseBucketId, 'PUT', buckets)
                            .then(response => {
                                if (response.ok) {
                                    return response.json();
                                }
                                throw new Error(response.status);
                            }).then(_ => callback());
                    });
            });
    }


}

function _ajax(url, method, body) {
    let options = {
        method: method || 'GET',
        headers: body ? {'Content-Type': 'application/json'} : {},
        body: body ? JSON.stringify(body) : null
    };
    return fetch(url, options);
}