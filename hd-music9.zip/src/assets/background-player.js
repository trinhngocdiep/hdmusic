class Player {

    constructor() {
        this.volume = 1;
        this.tracks = [];
        this.currentTrack = null;
        this.repeatEnabled = false;
        this.shuffleEnabled = true;
        this.playing = false;

        this._players = [new ScPlayer(), new YtPlayer()];
        this._currentPlayer = null;
        this._players.forEach(e => {
            e.onPlay = () => {
                this.playing = true;
                this.onPlay && this.onPlay(this.currentTrack);
                this.onStatusChange && this.onStatusChange();
                e.setVolume(this.volume);
            };
            e.onPause = () => {
                this.playing = false;
                this.onPause && this.onPause(this.currentTrack);
                this.onStatusChange && this.onStatusChange();
            };
            e.onEnd = () => {
                this.playing = false;
                this.onEnd && this.onEnd(this.currentTrack);
                this.onStatusChange && this.onStatusChange();
                if (this.repeatEnabled) {
                    this.play(this.currentTrack);
                } else {
                    this.next();
                }
            };
            e.onError = (error) => {
                this.playing = false;
                this.onError && this.onError(error);
                this.onStatusChange && this.onStatusChange();
                this.next();
            };
            e.onProgress = (time) => {
                this.onProgress && this.onProgress(this.currentTrack, time);
            };
        });
    }

    play(track) {
        let canPlay = false;
        this._players.forEach(e => {
            if (e.canPlay(track)) {
                this.currentTrack = track;
                this._currentPlayer = e;
                e.play(track);
                canPlay = true;
            } else {
                e.pause();
            }
        });
        if (!canPlay) {
            this.onError && this.onError('No player can play the track: ' + track.title);
        }
    }

    resume() {
        if (this._currentPlayer) {
            this._currentPlayer.resume(this.currentTrack);
        }
    }

    pause() {
        if (this._currentPlayer) {
            this._currentPlayer.pause();
        }
    }

    setVolume(volume) {
        this._players.forEach(e => e.setVolume(volume));
    }

    seek(time) {
        if (this._currentPlayer) {
            this._currentPlayer.seek(time);
        }
    }

    next() {
        if (!this.currentTrack || !this.tracks || this.tracks.length == 0) {
            return;
        }
        let currentIndex = this.tracks.indexOf(this.currentTrack);
        let nextTrack;
        if (this.shuffleEnabled) {
            nextTrack = this.tracks[getRandomNumberExcept(0, this.tracks.length - 1, currentIndex)];
        } else {
            nextTrack = this.tracks[currentIndex + 1];
        }
        this.play(nextTrack || this.tracks[0]);

        function getRandomNumberExcept(min, max, except) {
            // there's only one choice -- except
            if (except == min && except == max) {
                return except;
            }
            // random until a number different from the except is returned
            let random = except;
            do {
                random = Math.floor(Math.random() * (max - min + 1)) + min;
            } while (random == except);
            return random;
        }
    }

    previous() {
        if (!this.tracks || this.tracks.length == 0) {
            return;
        }
        if (!this.currentTrack) {
            return;
        }
        let currentIndex = this.tracks.indexOf(this.currentTrack);
        let previousTrack = this.tracks[currentIndex - 1];
        if (!previousTrack) {
            previousTrack = this.tracks[this.tracks.length - 1];
        }
        if (previousTrack) {
            this.play(previousTrack);
        }
    }

}