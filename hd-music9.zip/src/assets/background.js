(function () {

    let background = window.background = {
        state: {},
        storage: {},
        player: new Player(),
        noisePlayer: new NoisePlayer(),
        ready: false,
        onReady: null
    };

    // init user storage
    let userStorage = new UserStorage();
    userStorage.init(function () {
        background.ready = true;
        background.storage = userStorage.userBucket;
        background.storage.sync = function () {
            userStorage.sync();
        };
        background.onReady && background.onReady();
    });

    // create context menus
    let contextMenus = chrome && chrome.contextMenus;
    if (!contextMenus) {
        return;
    }

    const contextMenuId = 'playercontrol';

    contextMenus.create({
        id: contextMenuId,
        title: 'Play All',
        contexts: ['browser_action'],
        onclick: function () {
            console.log('context Play all');
            let tracks = background.storage.library.tracks;
            if (tracks && tracks.length > 0) {
                background.player.tracks = tracks;
                background.player.play(tracks[0]);
            }
        }
    });

    background.player.onStatusChange = function () {
        if (background.player.playing) {
            contextMenus.update(contextMenuId, {
                title: 'Pause',
                onclick: function () {
                    console.log('context Pause');
                    background.player.pause();
                }
            });
        } else {
            contextMenus.update(contextMenuId, {
                title: 'Play',
                onclick: function () {
                    console.log('context Play');
                    background.player.resume();
                }
            });
        }
    };
    
})();