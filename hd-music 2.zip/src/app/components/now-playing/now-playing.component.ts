import { Component, NgZone, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material';

declare var chrome;

import { ApiService } from '../../services/api.service';
import { DataService } from '../../services/data.service';
import { EventBusService } from '../../services/event-bus.service';

@Component({
    selector: 'now-playing',
    templateUrl: './now-playing.component.html',
    styleUrls: ['./now-playing.component.css']
})
export class NowPlayingComponent {
    constructor(
        private ngZone: NgZone,
        public snackBar: MatSnackBar,
        public dataService: DataService,
        public eventBus: EventBusService,
        public apiService: ApiService
    ){}

    @ViewChild('progress') progress;

    player;

    ngOnInit() {
        this.loadState();
        this.loadBackgroundPlayer();
        this.registerListeners();
    }

    ngAfterViewInit() {
        if (!this.player.tracks || this.player.tracks.length <= 0) {
            this.eventBus.navigate(2);
        }
    }

    private loadState() {
    }

    private loadBackgroundPlayer() {
        this.player = this.dataService.player;
        this.player.tracks = this.player.tracks || [];
        this.player.onPlay = () => {
            console.debug('onPlay');
            this.ngZone.run(() => {
                this.player.playing = true;
            });
        };
        this.player.onPause = () => {
            console.debug('onPause');
            this.ngZone.run(() => {
                this.player.playing = false;
            });
        };
        this.player.onProgress = (track, currentTime) => {
            console.debug('onProgress', currentTime);
            this.ngZone.run(() => {

                this.player.playing = true;

                // update progress bar's max and initial value
                if (this.progress && track.durationInSeconds) {
                    this.progress.max = track.durationInSeconds;
                    this.progress.value = currentTime;
                }
            });
        };
        this.player.onEnd = () => {
            console.debug('onEnd');
            this.ngZone.run(() => {
                this.player.playing = false;
            });
        };
        this.player.onError = (error) => {
            this.ngZone.run(() => {
                this.player.playing = false;
                this.snackBar.open(error || 'Cannot play track', null, {duration: 3000});
            });
        };
    }

    private registerListeners() {
        this.eventBus.onPlay$.subscribe(data => {
            if (data) {
                if (data instanceof Array) {
                    // multiple tracks
                    if (data.length == 0) {
                        return;
                    }
                    this.player.play(data[0]);
                    this.player.tracks = data;

                } else {
                    // single track
                    this.player.play(data);
                    this.player.tracks = [data];
                }
                this.ngZone.run(() => {
                    this.snackBar.open('Playing', null, {duration: 3000});
                });
            }
        });

        this.eventBus.onStop$.subscribe(stop => {
            if (stop) {
                console.debug('player stop event');
                this.player.pause();
            }
        });

        this.eventBus.onQueue$.subscribe(track => {
            if (track) {
                this.player.tracks.push(track);
                this.ngZone.run(() => {
                    this.snackBar.open('Added to playing queue', null, {duration: 3000});
                });
            }
        });
    }

    play(track) {
        if (this.player.playing && this.player.currentTrack && this.player.currentTrack.sourceUrl == track.sourceUrl) {
            return;
        }
        if (this.player.currentTrack && this.player.currentTrack.sourceUrl == track.sourceUrl) {
            this.player.resume();
        } else {
            this.player.play(track, this.player.tracks);
        }
    }

    seek(time) {
        this.player.seek(time);
    }

    playAll() {
        this.eventBus.playLib();
    }

    goToLib() {
        this.eventBus.navigate(1);
    }

    goToExplore() {
        this.eventBus.navigate(2);
    }


    goToOrigin(item) {
        let origin = item.sourceUrl;
        if (!origin) {
            return;
        }
        if (chrome.extension) {
            chrome.tabs.create({url: origin});
        } else {
            window.open(origin, '_blank');
        }
    }
}