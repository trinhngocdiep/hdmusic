import { Component, ViewChild } from '@angular/core';

import { EventBusService } from '../../services/event-bus.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {
    constructor(
        public eventBus: EventBusService
    ){}

    @ViewChild('tabGroup') tabGroup;

    ngOnInit() {
        this.eventBus.onNavigate$.subscribe(tabIndex => {
            if (tabIndex) {
                this.tabGroup.selectedIndex = tabIndex;
            }
        });
    }
}
