import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

declare var chrome;
declare var background;

import { EventBusService }  from './event-bus.service';

const DEFAULT_USER_ID = 'hd-music';

@Injectable()
export class DataService {

    constructor(
        private http: Http,
        private eventBus: EventBusService
    ) {
        this.initialize();
    }

    // background music player
    player: any;

    // local state for data sync between background and ui
    state: any;

    // cloud storage for data sync between devices
    cloudStorage: any;
    private cloudStorageBinId;

    private initialize() {
        let backgroundScript = this.loadBackgroundScript();
        this.player = backgroundScript.player;
        this.state = backgroundScript.state;

        this.getUserId((username) => {
            this.initializeCloudStorage(username);
        });
    }

    private loadBackgroundScript() {
        if (chrome.extension) {
            return chrome.extension.getBackgroundPage().background;
        }
        return background;
    }

    private initializeCloudStorage(username) {
        console.debug('getting base storage');
        this.http.get('https://api.myjson.com/bins/9hoin')
            .subscribe(response => {
                let users = response.json();
                console.debug('base storage', users);
                let userBinId = users[username];
                if (userBinId) {
                    this.cloudStorageBinId = userBinId;
                    console.debug('getting user data from bin id', userBinId);
                    this.http.get('https://api.myjson.com/bins/' + userBinId)
                        .subscribe(
                            response => {this.cloudStorage = response.json();},
                            error => {
                                if (error.status == 404) {
                                    console.debug('user data not found', error);
                                    this.createUserCloudStorage(users, username);
                                }
                            },
                            () => this.eventBus.initiated()
                    );
                } else {
                    this.createUserCloudStorage(users, username);
                }
            });
    }

    private getUserId(callback) {
        if (chrome.identity) {
            chrome.identity.getProfileUserInfo((userInfo) => {
                console.debug('found chrome user', userInfo);
                if (userInfo && userInfo.id) {
                    callback(userInfo.id);
                }
            });
        } else {
            console.debug('could not get chrome user. Using default user', DEFAULT_USER_ID);
            callback(DEFAULT_USER_ID);
        }
    }

    private createUserCloudStorage(users, username) {
        this.cloudStorage = {id: username};
        console.debug('creating user storage for:', this.cloudStorage);
        this.http.post('https://api.myjson.com/bins', this.cloudStorage)
            .subscribe(
                response => {
                    let uri = response.json().uri;
                    let createdBinId = uri.substr(uri.lastIndexOf('/') + 1);
                    this.cloudStorageBinId = createdBinId;

                    console.debug('adding new user to base storage. username = ', username, ', bin id = ', createdBinId);
                    users[username] = createdBinId;
                    this.http.put('https://api.myjson.com/bins/9hoin', users)
                        .subscribe(response => {
                            let json = response.json();
                            console.debug('updated base storage', json);
                        });
                },
                error => {},
                () => {this.eventBus.initiated()}
            );
    }

    updateCloudStorage() {
        console.debug('updating cloud storage');
        this.http.put('https://api.myjson.com/bins/' + this.cloudStorageBinId, this.cloudStorage)
            .subscribe(response => {
                console.debug('update response', response);
            });
    }

}