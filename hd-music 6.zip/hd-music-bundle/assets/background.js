(function() {

    if (window.debugging) {
        document.getElementById('btn-play').onclick = function() {
            background.player.play({videoId: document.getElementById('txt-video-id').value});
        };

        document.getElementById('btn-pause').onclick = function() {
            background.player.pause();
        };
    }


    let player = {
        // player state
        tracks: [],
        currentTrack: null,
        volume: 1,
        repeatEnabled: false,
        shuffleEnabled: false,

        // player functions
        play: play,
        pause: pause,
        next: next,
        previous: previous,
        seek: seek,
        resume: resume,
        setVolume: setVolume,
        onPlay: null,
        onProgress: null,
        onPause: null,
        onEnd: null,
        onError: null,

        // for internal use
        _onStatusChange: null
    };

    if (chrome && chrome.contextMenus) {
        player._onStatusChange = function() {
            console.debug('_onStatusChange event');
            chrome.contextMenus.removeAll();
            if (player.currentTrack) {
                if (player.playing) {
                    console.debug('adding pause menu');
                    chrome.contextMenus.create({
                        title: "Pause",
                        contexts: ["browser_action"],
                        onclick: function () {
                            player.pause();
                        }
                    });
                } else {
                    console.debug('adding play menu');
                    chrome.contextMenus.create({
                        title: "Play",
                        contexts: ["browser_action"],
                        onclick: function () {
                            player.resume();
                        }
                    });
                }
            }
        };
    }

    window.background = {
        state: {},
        player: player
    };

    // initialize players
    let _players = [new ScPlayer(), new YtPlayer()];
    let _currentPlayer;

    // register listeners
    _players.forEach(e => {
        e.onPlay = function() {
            player.onPlay && player.onPlay(player.currentTrack);
            e.setVolume(player.volume);
            _notifyInternalListeners();
        };
        e.onPause = function() {
            player.onPause && player.onPause(player.currentTrack);
            _notifyInternalListeners();
        };
        e.onProgress = function(time) {
            player.onProgress && player.onProgress(player.currentTrack, time);
        };
        e.onEnd = function() {
            player.onEnd && player.onEnd(player.currentTrack);
            next();
            _notifyInternalListeners();
        };
        e.onError = function(error) {
            player.onError && player.onError(error);
            next();
            _notifyInternalListeners();
        }
    });

    function _notifyInternalListeners() {
        player._onStatusChange && player._onStatusChange();
    }

    function play(track) {
        let canPlay = false;
        _players.forEach(e => {
            if (e.canPlay(track)) {
                player.currentTrack = track;
                _currentPlayer = e;
                e.play(track);
                canPlay = true;
            } else {
                e.pause();
            }
        });
        if (!canPlay) {
            player.onError && player.onError('No player can play the track: ' + track.title);
            return;
        }

        player.playing = true;
    }

    function resume() {
        if (_currentPlayer) {
            _currentPlayer.resume(player.currentTrack);
        }
    }

    function pause() {
        if (_currentPlayer) {
            _currentPlayer.pause();
            player.playing = false;
        }
    }

    function setVolume(volume) {
        _players.forEach(e => e.setVolume(volume));
    }

    function seek(time) {
        if (_currentPlayer) {
            _currentPlayer.seek(time);
        }
    }

    function next() {
        if (!player.currentTrack || !player.tracks || player.tracks.length == 0) {
            return;
        }
        let currentIndex = player.tracks.indexOf(player.currentTrack);
        let nextTrack;
        if (player.shuffleEnabled) {
            nextTrack = player.tracks[_getRandomNumberExcept(0, player.tracks.length - 1, currentIndex)];
        } else {
            nextTrack = player.tracks[currentIndex + 1];
        }
        if (nextTrack) {
            play(nextTrack);
        } else if (player.repeatEnabled) {
            play(player.tracks[0]);
        }
    }

    function previous() {
        if (!player.tracks || player.tracks.length == 0) {
            return;
        }
        if (!player.currentTrack) {
            return;
        }
        let currentIndex = player.tracks.indexOf(player.currentTrack);
        let previousTrack = player.tracks[currentIndex - 1];
        if (previousTrack) {
            play(previousTrack);
        }
    }

    function _getRandomNumberExcept(min, max, except) {
        // there's only one choice -- except
        if (except == min && except == max) {
            return except;
        }
        // random until a number different from the except is returned
        let random = except;
        do {
            random = Math.floor(Math.random() * (max - min + 1)) + min;
        } while (random == except);
        return random;
    }

})();