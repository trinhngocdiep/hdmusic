import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod } from '@angular/http';
import { Subject, Observable } from 'rxjs';

const SC_KEY = '458dac111e2456c40805cd838f4548c1'; // KyZEBUaphfHpKKZ9B0H9JsmvDULUPAkj
const YT_KEY = 'AIzaSyDGbUJxAkFnaJqlTD4NwDmzWxXAk55gFh4';

@Injectable()
export class ApiService {

    constructor(
        private http: Http
    ) {}

    suggest(query: string) {
        //return this.http.get('https://suggestqueries.google.com/complete/search?hl=en&client=firefox&q=' +query).map(data => data.json()[1]);
        return Observable.of([]);
    }

    getTopTracks() {
        //return this.http.get('https://api-v2.soundcloud.com/charts?kind=top&genre=soundcloud%3Agenres%3Aall-music&client_id=' + SC_KEY).map(response => {
        //    return response.json().collection.map(e => {
        //        return new Track(e.title, e.duration, e.artwork_url, e.uri + '&client_id=' + SC_KEY);
        //    });
        //});
    }

    search(query, offset) {
        return Observable.forkJoin(this.searchSc(query, offset), this.searchYt(query, offset))
            .map(data => {
                return {
                    tracks: data[0].tracks.concat(data[1].tracks),
                    offset: {
                        next_href: data[0].next_href,
                        pageToken: data[1].pageToken
                    }
                }
            });
    }

    private searchSc(query, offset) {
        //let scQuery = 'https://api.soundcloud.com/tracks?linked_partitioning=1&limit=10&client_id=' + SC_KEY + '&q=' + query;
        //if (offset) {
        //    // fetch next page
        //    if (offset.next_href) {
        //        scQuery = offset.next_href;
        //    } else {
        //        // no more result
        //        scQuery = null;
        //    }
        //}
        //if (scQuery) {
        //    return this.http.get(scQuery).map(response => {
        //        let data = response.json();
        //        let tracks = data.collection.filter(e => e.streamable).map(e => {
        //            let durationInSeconds = e.duration / 1000;
        //            return {
        //                title: '[SC]' + e.title,
        //                durationInSeconds: durationInSeconds,
        //                durationInMinutes: formatDuration(durationInSeconds),
        //                artwork_url: e.artwork_url,
        //                stream_url: e.stream_url
        //            };
        //        });
        //        return {
        //            tracks: tracks,
        //            next_href: data.next_href
        //        }
        //    });
        //}

        return Observable.of({
            tracks: [],
            next_href: null
        });
    }

    private searchYt(query, offset) {
        let ytSearchQuery = 'https://www.googleapis.com/youtube/v3/search?key=' + YT_KEY + '&part=id&type=video&q=' + query;
        if (offset) {
            // fetch next page
            if (offset.pageToken) {
                ytSearchQuery += '&pageToken=' + offset.pageToken;
            } else {
                // no more result
                ytSearchQuery = null;
            }
        }
        if (ytSearchQuery) {
            let nextPageToken;
            return this.http.get(ytSearchQuery)
                .map(response => {
                    let data = response.json();
                    nextPageToken = data.nextPageToken;
                    return data.items.map(e => e.id.videoId);
                })
                .flatMap(videoIds => {
                    return this.http.get('https://www.googleapis.com/youtube/v3/videos?key=' + YT_KEY + '&part=snippet,contentDetails,player&id=' + videoIds.join(','))
                        .map(response => {
                            let videos = response.json().items.map(e => {
                                let durationInSeconds = isoDurationToSeconds(e.contentDetails.duration);
                                return {
                                    title: '[YT]' + e.snippet.title,
                                    durationInSeconds: durationInSeconds,
                                    durationInMinutes: formatDuration(durationInSeconds),
                                    artwork_url: e.snippet.thumbnails.default.url,
                                    videoId: e.id,
                                    playerCode: e.player.embedHtml
                                };
                            });
                            return {
                                tracks: videos,
                                pageToken: nextPageToken
                            };
                        });
                });
        }
        return Observable.of({
            tracks: [],
            pageToken: null
        });
    }
}

function isoDurationToSeconds(value: string) {
    var reptms = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/;
    var hours = 0, minutes = 0, seconds = 0;

    if (reptms.test(value)) {
        var matches = reptms.exec(value);
        if (matches[1]) hours = Number(matches[1]);
        if (matches[2]) minutes = Number(matches[2]);
        if (matches[3]) seconds = Number(matches[3]);
        return hours * 3600  + minutes * 60 + seconds;
    }
    return 0;
}

function formatDuration(seconds) {
    let mins = Math.floor(seconds / 60);
    return mins + ':' + Math.floor(seconds - mins * 60);
}