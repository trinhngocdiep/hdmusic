import { NgModule } from '@angular/core';
import { CommonModule, JsonPipe, DatePipe } from '@angular/common';
import { HttpModule, Http } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { MaterialModule } from './material.module';

import { DurationPipe } from './pipes/custome.pipe';

import { DataService } from './services/data.service';
import { ApiService } from './services/api.service';
import { EventBusService } from './services/event-bus.service';

import { AppComponent } from './components/app/app.component';
import { NowPlayingComponent } from './components/now-playing/now-playing.component';
import { MusicManagerComponent } from './components/music-manager/music-manager.component';
import { MusicExplorerComponent } from './components/music-explorer/music-explorer.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        BrowserModule,
        FormsModule,
        HttpModule,
        BrowserAnimationsModule,
        MaterialModule
    ],
    providers: [
        EventBusService,
        DataService,
        ApiService,
        DatePipe
    ],
    declarations: [
        DurationPipe,

        AppComponent,
        NowPlayingComponent,
        MusicManagerComponent,
        MusicExplorerComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
