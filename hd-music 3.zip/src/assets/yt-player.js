class YtPlayer {

    constructor() {
        const PROXY_ORIGIN = 'https://run.plnkr.co';
        const PROXY_URL = 'https://embed.plnkr.co/MNdfj0xNEyWJNJQqpMO5?show=preview';

        window.onload = () => {
            let baseIframe = document.createElement('iframe');
            document.body.appendChild(baseIframe);
            baseIframe.width = '100%';
            baseIframe.height = '500';
            baseIframe.src = PROXY_URL;
            baseIframe.style.display = 'none';
        };

        window.addEventListener("message", (message) => {
            console.log('background player received message', message);
            let origin = message.origin;
            let data = message.data;
            if (origin != PROXY_ORIGIN) {
                return;
            }

            // listen to change in the plunker to get the newly updated view id
            if (data.data && data.data.method == 'onLocationChange') {
                // init proxy window
                this.proxyUrl = PROXY_ORIGIN + '/preview/' + data.sourceChannel + '/';
                let proxyIframe = document.createElement('iframe');
                document.body.appendChild(proxyIframe);
                proxyIframe.src = this.proxyUrl;
                proxyIframe.width = '100%';
                proxyIframe.height = '500';
                proxyIframe.style.display = 'none';
                this.proxy = proxyIframe.contentWindow;
                console.log('Proxy ready', this.proxyUrl);
                return;
            }
            // messages from proxy player
            this._dispatch(message.data.event, message.data.data);
        });
    }

    _dispatch(event, data) {
        switch (event) {
            case 'onPlay': {
                if (window.debugging) {
                    document.getElementById('txt-status').innerText = 'Playing';
                }
                this.onPlay && this.onPlay();
                break;
            }
            case 'onPause': {
                if (window.debugging) {
                    document.getElementById('txt-status').innerText = 'Paused';
                }
                this.onPause && this.onPause();
                break;
            }
            case 'onEnd': {
                if (window.debugging) {
                    document.getElementById('txt-status').innerText = 'Ended';
                }
                this.onEnd && this.onEnd();
                break;
            }
            case 'onError': {
                if (window.debugging) {
                    document.getElementById('txt-status').innerText = 'Error: ' + data;
                }
                this.onError && this.onError(data);
                break;
            }
            case 'onProgress': {
                if (window.debugging) {
                    document.getElementById('txt-progress').innerText = 'Current Progress: ' + data;
                }
                this.onProgress && this.onProgress(data);
                break;
            }
        }
    }

    _postMessageToProxy(message) {
        if (!this.proxy) {
            console.log('Proxy window is not ready');
            this.onError && this.onError('Player is not ready');
            return;
        }
        this.proxy.postMessage(message, '*');
    }

    canPlay(track) {
        return !!track.videoId || !!track.playlistId;
    }

    play(track) {
        this._postMessageToProxy({command: 'play', data: track});
    }

    resume(track) {
        this._postMessageToProxy({command: 'resume', data: track});
    }

    pause() {
        this._postMessageToProxy({command: 'pause'});
    }

    seek(time) {
        this._postMessageToProxy({command: 'seek', data: time});
    }

    setVolume(volume) {
        this._postMessageToProxy({command: 'setVolume', data: volume});
    }

}