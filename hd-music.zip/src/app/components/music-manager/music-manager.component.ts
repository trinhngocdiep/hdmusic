import { Component, ViewChild, ViewEncapsulation, NgZone } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

import { DataService } from '../../services/data.service';
import { ApiService } from '../../services/api.service';
import { EventBusService } from '../../services/event-bus.service';

@Component({
    selector: 'music-manager',
    templateUrl: './music-manager.component.html',
    styleUrls: ['./music-manager.component.css']
})
export class MusicManagerComponent {
    constructor(
        public ngZone: NgZone,
        public snackBar: MatSnackBar,
        public dataService: DataService,
        public eventBus: EventBusService,
        public apiService: ApiService
    ){}

    state;
    player;
    cloudLibrary;
    dataSource = new DataSource();

    private queries = new Subject<string>();

    ngOnInit() {
        this.loadState();
        this.registerListeners();
    }

    private loadState() {
        this.state = this.dataService.state.library;
        this.player = this.dataService.player;
        if (!this.state) {
            this.state = this.dataService.state.library = {};
        }
        if (!this.state.tracks) {
            this.state.tracks = [];
        }
        this.updateDataTable();
    }

    private registerListeners() {
        this.eventBus.onInitiated$.subscribe(initiated => {
            console.debug('initiated event');
            if (initiated) {
                let cloudStorage = this.dataService.cloudStorage;
                if (cloudStorage) {
                    if (cloudStorage.library) {
                        console.debug('found existing cloud library', cloudStorage.library);
                        this.cloudLibrary = cloudStorage.library;
                        this.state.tracks = this.cloudLibrary.tracks;
                        this.updateDataTable();
                    } else {
                        console.debug('initiating cloud library');
                        this.cloudLibrary = cloudStorage.library = {};
                    }
                } else {
                    console.debug('could not load cloud storage');
                }
            }
        });

        this.eventBus.onAddToLib$.subscribe(item => {
            console.debug('add-to-lib event', item);
            if (item) {
                if (this.state.tracks.find(e => e.title == item.title)) {
                    console.debug('item already existed in lib');
                    this.ngZone.run(() => {
                        this.snackBar.open('Track already existing in library', null, {duration: 3000});
                    });
                    return;
                }
                // update local state
                this.state.tracks.unshift(item);

                // update table
                this.updateDataTable();

                // update cloud library
                if (this.cloudLibrary) {
                    this.cloudLibrary.tracks = this.state.tracks;
                    this.dataService.updateCloudStorage();
                }

                this.ngZone.run(() => {
                    this.snackBar.open('Added to library', null, {duration: 3000});
                });
            }
        });

        this.eventBus.onPlayLib$.subscribe(play => {
            console.debug('play-lib event');
            if (play) {
                this.playAll();
            }
        });

        this.queries.debounceTime(500).distinctUntilChanged()
            .subscribe(term => {
                this.dataSource.filter = term;
            });
    }

    private updateDataTable() {
        this.dataSource.data = this.state.tracks;
    }

    playAll() {
        if (this.state.tracks && this.state.tracks.length > 0) {
            this.eventBus.play(this.state.tracks);
        } else {
            this.eventBus.navigate(2);
        }
    }

    play(track) {
        this.eventBus.play(track);
    }

    stop() {
        this.eventBus.stop();
    }

    queue(track) {
        this.eventBus.queue(track);
    }

    delete(track) {
        // update local state
        let index = this.state.tracks.indexOf(track);
        this.state.tracks.splice(index, 1);

        this.updateDataTable();

        this.ngZone.run(() => {
            let undoed = false;
            let snackBarRef = this.snackBar.open('Removed from library', 'Undo', {duration: 5000});
            snackBarRef.onAction().subscribe(() => {
                console.debug('undoing remove from library');
                this.state.tracks.splice(index, 0, track);
                this.updateDataTable();
                undoed = true;
            });
            snackBarRef.afterDismissed().subscribe(() => {
                console.debug('removing item from cloud library', track);
                if (!undoed) {
                    // update cloud library
                    if (this.cloudLibrary) {
                        this.cloudLibrary.tracks = this.state.tracks;
                        this.dataService.updateCloudStorage();
                    }
                }
            });
        });
    }

    goToExplore() {
        this.eventBus.navigate(2);
    }

    onSearchTextType() {
        console.debug('onSearchTextType');
        this.queries.next(this.state.searchTerm);
    }

    onSearchTextClear() {
        this.state.searchTerm = null;
        this.queries.next(this.state.searchTerm);
    }

    onSort(event) {
        this.dataSource.sort = event;
    }
}

class DataSource {
    _dataSource = new BehaviorSubject([]);
    _filterChange = new BehaviorSubject('');
    _sortChange = new BehaviorSubject(null);
    _output = new BehaviorSubject(null);

    get data(): Array<any> {return this._dataSource.value;}
    set data(data) {this._dataSource.next(data);}

    get filter(): string {return this._filterChange.value;}
    set filter(filter: string) {this._filterChange.next(filter);}

    get sort(): any {return this._sortChange.value;}
    set sort(sort: any) {this._sortChange.next(sort);}

    get length(): any {return this._output.value && this._output.value.length;}

    connect(): Observable<any> {
        console.debug('connect');
        Observable.merge(this._dataSource, this._filterChange, this._sortChange)
            .debounceTime(100)
            .map(() => {
                console.debug('datasource change');
                let output = this.data;
                let filter = this.filter;
                if (filter) {
                    output = this.data.filter(e => {
                        return e.title.toLocaleLowerCase().indexOf(filter.toLocaleLowerCase()) >= 0;
                    });
                } else {
                    output = this.data;
                }

                let sort = this.sort;
                if (sort) {
                    let sortField = sort.active;
                    let isAsc = sort.direction == 'asc';
                    if (sortField) {
                        output = this.data.sort((a, b) => {
                            return compare(a[sortField], b[sortField], isAsc);
                        });
                    }
                }
                return output;
            })
            .subscribe(data => {
                console.debug('incoming data', data);
                this._output.next(data);
            });

        return this._output.asObservable();
    }

    disconnect() {
        this._dataSource.complete();
        this._filterChange.complete();
        this._sortChange.complete();
    }

}

function compare(a, b, isAsc) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}