import { Injectable, NgZone } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class EventBusService {

    private onLoading: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    onLoading$ = this.onLoading.asObservable();

    private onInitiated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    onInitiated$ = this.onInitiated.asObservable();

    private onNavigate: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onNavigate$ = this.onNavigate.asObservable();

    private onPlay: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onPlay$ = this.onPlay.asObservable();

    private onStop: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onStop$ = this.onStop.asObservable();

    private onPlayLib: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onPlayLib$ = this.onPlayLib.asObservable();

    private onQueue: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onQueue$ = this.onQueue.asObservable();

    private onAddToLib: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    onAddToLib$ = this.onAddToLib.asObservable();

    loading(loading) {
        this.onLoading.next(loading);
    }

    initiated() {
        this.onInitiated.next(true);
    }

    navigate(tabIndex) {
        this.onNavigate.next(tabIndex);
    }

    play(item) {
        this.onPlay.next(item);
    }

    stop() {
        this.onStop.next(true);
    }

    queue(item) {
        this.onQueue.next(item);
    }

    addToLib(item) {
        this.onAddToLib.next(item);
    }

    playLib() {
        this.onPlayLib.next(true);
    }
}