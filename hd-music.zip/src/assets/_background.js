(function() {

    let player = {
        // player state
        tracks: [],
        currentTrack: null,
        volume: 1,

        // player functions
        play: play,
        pause: pause,
        next: next,
        previous: previous,
        seek: seek,
        resume: resume,
        setVolume: setVolume,
        onPlay: null,
        onProgress: null,
        onPause: null,
        onEnd: null,
        onError: null,

        // for internal use
        _onStatusChange: null
    };

    if (chrome && chrome.contextMenus) {
        player._onStatusChange = function() {
            console.debug('_onStatusChange event');
            chrome.contextMenus.removeAll();
            if (player.currentTrack) {
                if (player.playing) {
                    console.debug('adding pause menu');
                    chrome.contextMenus.create({
                        title: "Pause",
                        contexts: ["browser_action"],
                        onclick: function () {
                            player.pause();
                        }
                    });
                } else {
                    console.debug('adding play menu');
                    chrome.contextMenus.create({
                        title: "Play",
                        contexts: ["browser_action"],
                        onclick: function () {
                            player.resume();
                        }
                    });
                }
            }
        };
    }

    window.background = {
        state: {},
        player: player
    };

    // initialize players
    let _players = [new ScPlayer(), new YtPlayer()];
    let _currentPlayer;

    // register listeners
    _players.forEach(e => {
        e.onPlay = function() {
            player.onPlay && player.onPlay(player.currentTrack);
            e.setVolume(player.volume);
            _notifyInternalListeners();
        };
        e.onPause = function() {
            player.onPause && player.onPause(player.currentTrack);
            _notifyInternalListeners();
        };
        e.onProgress = function(time) {
            player.onProgress && player.onProgress(player.currentTrack, time);
        };
        e.onEnd = function() {
            player.onEnd && player.onEnd(player.currentTrack);
            next();
            _notifyInternalListeners();
        };
        e.onError = function(error) {
            player.onError && player.onError(error);
            next();
            _notifyInternalListeners();
        }
    });

    function _notifyInternalListeners() {
        player._onStatusChange && player._onStatusChange();
    }

    function play(track) {
        let canPlay = false;
        _players.forEach(e => {
            if (e.canPlay(track)) {
                player.currentTrack = track;
                _currentPlayer = e;
                e.play(track);
                canPlay = true;
            } else {
                e.pause();
            }
        });
        if (!canPlay) {
            player.onError && player.onError('No player can play the track: ' + track.title);
            return;
        }

        player.playing = true;
    }

    function resume() {
        if (_currentPlayer) {
            _currentPlayer.resume(player.currentTrack);
        }
    }

    function pause() {
        if (_currentPlayer) {
            _currentPlayer.pause();
            player.playing = false;
        }
    }

    function setVolume(volume) {
        _players.forEach(e => e.setVolume(volume));
    }

    function seek(time) {
        if (_currentPlayer) {
            _currentPlayer.seek(time);
        }
    }

    function next() {
        if (!player.tracks || player.tracks.length == 0) {
            return;
        }
        if (!player.currentTrack) {
            return;
        }
        let currentIndex = player.tracks.indexOf(player.currentTrack);
        let nextTrack = player.tracks[currentIndex + 1];
        if (nextTrack) {
            play(nextTrack);
        }
    }

    function previous() {
        if (!player.tracks || player.tracks.length == 0) {
            return;
        }
        if (!player.currentTrack) {
            return;
        }
        let currentIndex = player.tracks.indexOf(player.currentTrack);
        let previousTrack = player.tracks[currentIndex - 1];
        if (previousTrack) {
            play(previousTrack);
        }
    }

})();

/** SC Player **/
function ScPlayer() {
    this.audio = new Audio();
    this.audio.ontimeupdate = () => {
        this.onProgress && this.onProgress(this.audio.currentTime);
    };
    this.audio.onpause = () => {
        this.onPause && this.onPause();
        if (this.audio.ended) {
            this.onEnd && this.onEnd();
        }
    };
}
ScPlayer.prototype.canPlay = function(track) {
    return !!track.stream_url;
};
ScPlayer.prototype.play = function(track) {
    if (!this.canPlay(track)) {
        return;
    }
    this.audio.src = track.stream_url;
    this.audio.play();
    this.onPlay && this.onPlay();
};
ScPlayer.prototype.resume = function(track) {
    if (!this.canPlay(track)) {
        return;
    }
    if (this.audio.src == track.stream_url) {
        this.audio.play();
        this.onPlay && this.onPlay();
    }
};
ScPlayer.prototype.pause = function() {
    this.audio.pause();
};
ScPlayer.prototype.seek = function(time) {
    this.audio.currentTime = time;
    if (this.audio.paused) {
        this.audio.play();
    }
};
ScPlayer.prototype.setVolume = function(volume) {
    this.audio.volume = volume;
};

/** YT player **/
function YtPlayer() {
    this.player = {initiated: false};
    this.containerId = 'ytPlayer';
    window.onload = () => {
        //let ytContainer = document.createElement('div');
        //ytContainer.id = this.containerId;
        //ytContainer.style.display = 'none';
        //document.body.appendChild(ytContainer);
    };
}
YtPlayer.prototype.canPlay = function(track) {
    return !!track.videoId || !!track.playlistId;
};
YtPlayer.prototype.play = function(track) {
    if (!this.canPlay(track)) {
        return;
    }
    this.track = track;
    if (this.player.playVideo) {
        if (this.track.videoId) {
            this.player.loadVideoById(this.track.videoId);
        } else if (this.track.playlistId) {
            this.player.loadPlaylist({listType: 'playlist', list: this.track.playlistId});
        }
    } else {
        let playerOptions = {
            height: '400',
            width: '400',
            events: {
                onReady: () => {
                    console.log('onReady');
                    this.player.playVideo();
                    this.onPlay && this.onPlay();
                },
                onStateChange: () => {
                    let playerState = this.player.getPlayerState();
                    console.log('onReady', playerState);
                    if (playerState == YT.PlayerState.PLAYING) {
                        this.onPlay && this.onPlay();
                        this.updateProgress();
                    } else if (playerState == YT.PlayerState.PAUSED) {
                        this.onPause && this.onPause(this.track);
                    } else if (playerState == YT.PlayerState.ENDED) {
                        this.onEnd && this.onEnd();
                    }
                },
                onError: (event) => {
                    console.log('cannot play video. Error code:', event.data);
                    this.onError && this.onError('Cannot play YouTube video', this.track.title);
                }
            },
            videoId: this.track.videoId
        };
        if (this.track.videoId) {
            playerOptions.videoId = this.track.videoId;
        } else if (this.track.playlistId) {
            playerOptions.playerVars = {listType: 'playlist', list: this.track.playlistId};
        }
        this.player = new YT.Player(this.containerId, playerOptions);
    }
};
YtPlayer.prototype.resume = function(track) {
    let playerState = this.player.getPlayerState();
    if (playerState == YT.PlayerState.ENDED || playerState == YT.PlayerState.PAUSED) {
        if (this.track && this.track.videoId == track.videoId) {
            this.player.playVideo();
        } else {
            console.log('cannot resume video because the current track is different', this.track, track);
        }
    } else {
        this.onError && this.onError('cannot resume video because its state is: ' + playerState);
    }
};
YtPlayer.prototype.pause = function() {
    this.player.pauseVideo && this.player.pauseVideo();
};
YtPlayer.prototype.seek = function(time) {
    this.player.seekTo && this.player.seekTo(time, true);
};
YtPlayer.prototype.setVolume = function(volume) {
    if (this.player.setVolume) {
        // set volume does not unmute the video. WTF!
        this.player.unMute();
        this.player.setVolume(volume * 100)
    }
};
YtPlayer.prototype.updateProgress = function() {
    if (YT.PlayerState.PLAYING == this.player.getPlayerState()) {
        this.onProgress && this.onProgress(this.player.getCurrentTime());
        setTimeout(() => this.updateProgress(), 1000); // update progress every 1 second
    }
};