/** SC Player **/
function ScPlayer() {
    this.audio = new Audio();
    this.audio.ontimeupdate = () => {
        this.onProgress && this.onProgress(this.audio.currentTime);
    };
    this.audio.onpause = () => {
        this.onPause && this.onPause();
        if (this.audio.ended) {
            this.onEnd && this.onEnd();
        }
    };
}
ScPlayer.prototype.canPlay = function(track) {
    return !!track.stream_url;
};
ScPlayer.prototype.play = function(track) {
    if (!this.canPlay(track)) {
        return;
    }
    this.audio.src = track.stream_url;
    this.audio.play();
    this.onPlay && this.onPlay();
};
ScPlayer.prototype.resume = function(track) {
    if (!this.canPlay(track)) {
        return;
    }
    if (this.audio.src == track.stream_url) {
        this.audio.play();
        this.onPlay && this.onPlay();
    }
};
ScPlayer.prototype.pause = function() {
    this.audio.pause();
};
ScPlayer.prototype.seek = function(time) {
    this.audio.currentTime = time;
    if (this.audio.paused) {
        this.audio.play();
    }
};
ScPlayer.prototype.setVolume = function(volume) {
    this.audio.volume = volume;
};