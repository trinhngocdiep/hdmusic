package example.rss.reader.processors;

import example.rss.reader.core.RssItem;
import example.rss.reader.core.RssChannel;
import example.rss.reader.core.RssParseResult;
import example.rss.reader.core.RssProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class KeywordFilter implements RssProcessor {

    private static final Logger log = LoggerFactory.getLogger(KeywordFilter.class);

    private static final List<String> BLACKLIST = Collections.singletonList("newspick");

    @Override
    public void process(RssParseResult parseResult) {
        if (!parseResult.isSuccess()) {
            return;
        }

        RssChannel channel = parseResult.getResult();
        removeItemsContainingBlacklistedKeywords(channel);
    }

    private void removeItemsContainingBlacklistedKeywords(RssChannel channel) {
        Iterator<RssItem> itemIterator = channel.getItems().iterator();
        while(itemIterator.hasNext()) {
            RssItem item = itemIterator.next();
            if (BLACKLIST.contains(item.getDescription().toLowerCase())) {
                log.debug("Item removed because of blacklist keyword: %s", item.getDescription());
                itemIterator.remove();
            }
        }
    }

}
