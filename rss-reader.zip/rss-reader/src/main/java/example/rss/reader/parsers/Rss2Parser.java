package example.rss.reader.parsers;

import example.rss.reader.core.*;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.IOException;

public class Rss2Parser implements RssParser {

    private static final String CHANNEL = "channel";
    private static final String TITLE = "title";
    private static final String LINK = "link";
    private static final String DESCRIPTION = "description";
    private static final String LAST_BUILD_DATE = "lastBuildDate";
    private static final String GENERATOR = "generator";
    private static final String DOCS = "docs";
    private static final String ITEM = "item";
    private static final String PUB_DATE = "pubDate";
    private static final String GUID = "guid";

    @Override
    public boolean canParse(RssSource source) {
        return source.getType() == RssSource.Type.RSS_2_0;
    }

    @Override
    public RssParseResult parse(RssSource source) {
        try {
            XMLEventReader reader = getXmlEventReader(source);
            RssChannel channel = null;
            while (reader.hasNext()) {
                XMLEvent event = reader.nextEvent();
                if (event.isStartElement()) {
                    if (CHANNEL.equals(event.asStartElement().getName().getLocalPart())) {
                        channel = parseChannel(event, reader);
                    }
                }
            }
            return RssParseResult.success(channel);
        } catch (XMLStreamException | RssParseException ex) {
            return RssParseResult.error("Error parsing RSS source: " + source + ". Error: " + ex.getMessage());
        }
    }

    private RssChannel parseChannel(XMLEvent startEvent, XMLEventReader reader) throws XMLStreamException {
        RssChannel channel = new RssChannel();
        while (reader.hasNext()) {
            XMLEvent event = reader.nextEvent();
            if (event.isStartElement()) {
                String tagName = event.asStartElement().getName().getLocalPart();
                switch (tagName) {
                    case TITLE:
                        channel.setTitle(reader.getElementText());
                        break;
                    case DESCRIPTION:
                        channel.setDescription(reader.getElementText());
                        break;
                    case LINK:
                        channel.setLink(reader.getElementText());
                        break;
                    case LAST_BUILD_DATE:
                        channel.setLastBuildDate(reader.getElementText());
                        break;
                    case DOCS:
                        channel.setDocs(reader.getElementText());
                        break;
                    case GENERATOR:
                        channel.setGenerator(reader.getElementText());
                        break;
                    case ITEM:
                        channel.getItems().add(parseItem(reader));
                        break;
                }
            }
            if (event.isEndElement()) {
                if (CHANNEL.equals(event.asEndElement().getName().getLocalPart())) {
                    break;
                }
            }
        }

        if (!channel.validate()) {
            throw new RssParseException("Invalid RSS Channel at: " + startEvent.getLocation());
        }
        return channel;
    }

    private RssItem parseItem(XMLEventReader reader) throws XMLStreamException {
        RssItem item = new RssItem();
        while (reader.hasNext()) {
            XMLEvent event = reader.nextEvent();
            if (event.isStartElement()) {
                String tagName = event.asStartElement().getName().getLocalPart();
                switch (tagName) {
                    case TITLE:
                        item.setTitle(reader.getElementText());
                        break;
                    case DESCRIPTION:
                        item.setDescription(reader.getElementText());
                        break;
                    case LINK:
                        item.setLink(reader.getElementText());
                        break;
                    case PUB_DATE:
                        item.setPubDate(reader.getElementText());
                        break;
                    case GUID:
                        item.setGuid(reader.getElementText());
                        break;
                }
            }
            if (event.isEndElement()) {
                if (ITEM.equals(event.asEndElement().getName().getLocalPart())) {
                    break;
                }
            }
        }
        return item.validate();
    }

    private XMLEventReader getXmlEventReader(RssSource source) throws XMLStreamException {
        try {
            return XMLInputFactory.newInstance().createXMLEventReader(source.getData());
        } catch (IOException e) {
            throw new XMLStreamException(e);
        }
    }

}
