package example.rss.reader.core;

public class RssParseException extends RuntimeException {
    public RssParseException(String error) {
        super(error);
    }
}
