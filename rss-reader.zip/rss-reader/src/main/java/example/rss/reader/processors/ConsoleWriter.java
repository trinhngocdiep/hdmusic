package example.rss.reader.processors;

import com.google.gson.Gson;
import example.rss.reader.core.RssParseResult;
import example.rss.reader.core.RssProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsoleWriter implements RssProcessor {

    private static final Logger log = LoggerFactory.getLogger(ConsoleWriter.class);
    private static final Gson jsonSerializer = new Gson();

    @Override
    public void process(RssParseResult parseResult) {
        log.info("Parse result: {}", jsonSerializer.toJson(parseResult));
    }
}
