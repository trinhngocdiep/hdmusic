package example.rss.reader.sources;

import example.rss.reader.core.RssSource;

import java.io.IOException;
import java.io.InputStream;

public class LocalSource implements RssSource {

    private Type type;
    private InputStream inputStream;

    public LocalSource(Type type, InputStream inputStream) {
        this.type = type;
        this.inputStream = inputStream;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public InputStream getData() throws IOException {
        return inputStream;
    }

}
