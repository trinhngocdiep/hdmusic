package example.rss.reader.sources;

import example.rss.reader.core.RssSource;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;

public class RemoteSource implements RssSource {

    private static final Logger log = LoggerFactory.getLogger(RemoteSource.class);

    private static final HttpClient HTTP_CLIENT = HttpClientBuilder.create().build();

    private Type type;
    private String url;

    public RemoteSource(Type type, String url) {
        this.type = type;
        this.url = url;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public InputStream getData() throws IOException {
        log.info("Fetching data from: {}", url);
        HttpResponse response = HTTP_CLIENT.execute(new HttpGet(url));
        int statusCode = response.getStatusLine().getStatusCode();
        if (HttpStatus.SC_OK != statusCode) {
            throw new IOException("Could not get RSS data from: " + url + ". Response code: " + statusCode);
        }
        return response.getEntity().getContent();
    }

    @Override
    public String toString() {
        return url;
    }
}
