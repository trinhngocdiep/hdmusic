package example.rss.reader.processors;

import com.google.gson.Gson;
import example.rss.reader.core.RssParseResult;
import example.rss.reader.core.RssProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CustomFileWriter implements RssProcessor {

    private static final Logger log = LoggerFactory.getLogger(CustomFileWriter.class);
    private static final Gson jsonSerializer = new Gson();

    private File outputFile;

    public CustomFileWriter(File file) {
        this.outputFile = file;
    }

    @Override
    public void process(RssParseResult parseResult) {
        log.debug("Writing parse result to: {}", outputFile.getAbsolutePath());
        writeParseResultToFile(parseResult, outputFile);
    }

    private void writeParseResultToFile(RssParseResult parseResult, File file) {
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(jsonSerializer.toJson(parseResult));
        } catch (IOException e) {
            log.error("Error writing to file", e);
        }
    }
}
