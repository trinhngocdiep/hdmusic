package example.rss.reader.core;

import java.util.ArrayList;
import java.util.List;

public class RssChannel {

    private String title;
    private String link;
    private String lastBuildDate;
    private String description;
    private String docs;
    private String generator;
    private List<RssItem> items = new ArrayList<>();

    public boolean validate() {
        return title != null && link != null && description != null;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLastBuildDate() {
        return lastBuildDate;
    }

    public void setLastBuildDate(String lastBuildDate) {
        this.lastBuildDate = lastBuildDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDocs() {
        return docs;
    }

    public void setDocs(String docs) {
        this.docs = docs;
    }

    public String getGenerator() {
        return generator;
    }

    public void setGenerator(String generator) {
        this.generator = generator;
    }

    public List<RssItem> getItems() {
        return items;
    }

    public void setItems(List<RssItem> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return String.format("RSS Channel = {title = %s, link = %s, description = %s, items = %s}", title, link, description, items.size());
    }
}
