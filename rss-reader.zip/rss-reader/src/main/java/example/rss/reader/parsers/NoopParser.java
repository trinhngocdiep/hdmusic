package example.rss.reader.parsers;

import example.rss.reader.core.RssParser;
import example.rss.reader.core.RssSource;
import example.rss.reader.core.RssParseResult;

public class NoopParser implements RssParser {
    @Override
    public boolean canParse(RssSource source) {
        return false;
    }

    @Override
    public RssParseResult parse(RssSource source) {
        throw new UnsupportedOperationException("This is a dummy parser.");
    }
}
