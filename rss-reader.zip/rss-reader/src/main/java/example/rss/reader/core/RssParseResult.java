package example.rss.reader.core;

public class RssParseResult {

    private RssChannel result;
    private String error;

    public RssParseResult(RssChannel result, String error) {
        this.result = result;
        this.error = error;
    }

    public RssChannel getResult() {
        return result;
    }

    public String getError() {
        return error;
    }

    public boolean isSuccess() {
        return result != null && error == null;
    }

    public static RssParseResult success(RssChannel channel) {
        return new RssParseResult(channel, null);
    }

    public static RssParseResult error(String error) {
        return new RssParseResult(null, error);
    }

}
