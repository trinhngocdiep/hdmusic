package example.rss.reader.core;

public interface RssParser {

    boolean canParse(RssSource source);

    RssParseResult parse(RssSource source);

}
