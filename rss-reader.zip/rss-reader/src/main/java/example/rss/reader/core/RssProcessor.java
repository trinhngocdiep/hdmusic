package example.rss.reader.core;

public interface RssProcessor {

    void process(RssParseResult parseResult);

}
