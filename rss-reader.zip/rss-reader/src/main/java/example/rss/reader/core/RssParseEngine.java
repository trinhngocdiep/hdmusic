package example.rss.reader.core;

import java.util.Collections;
import java.util.List;

public class RssParseEngine {

    private List<RssParser> parsers;
    private List<RssProcessor> processors;

    public RssParseEngine(List<RssParser> parsers,
                          List<RssProcessor> processors) {
        this.parsers = parsers;
        this.processors = processors;
    }

    public RssParseResult run(RssSource source) {
        return parsers.stream().filter(parser -> parser.canParse(source)).findFirst()
                .map(parser -> parser.parse(source))
                .map(parseResult -> {
                    processors.forEach(processor -> processor.process(parseResult));
                    return parseResult;
                })
                .orElseThrow(() -> new IllegalArgumentException("No suitable parser for RSS type: " + source.getType()));
    }

    public List<RssParser> getParsers() {
        return Collections.unmodifiableList(parsers);
    }

    public List<RssProcessor> getProcessors() {
        return Collections.unmodifiableList(processors);
    }
}
