package example.rss.reader.core;

import java.io.IOException;
import java.io.InputStream;

public interface RssSource {

    enum Type {
        RSS_2_0
    }

    Type getType();

    InputStream getData() throws IOException;

}
