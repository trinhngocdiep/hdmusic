package example.rss.reader;

import example.rss.reader.core.RssParseEngine;
import example.rss.reader.core.RssParser;
import example.rss.reader.core.RssProcessor;
import example.rss.reader.core.RssSource;
import example.rss.reader.parsers.NoopParser;
import example.rss.reader.parsers.Rss2Parser;
import example.rss.reader.processors.ConsoleWriter;
import example.rss.reader.processors.CustomFileWriter;
import example.rss.reader.processors.KeywordFilter;
import example.rss.reader.sources.LocalSource;
import example.rss.reader.sources.RemoteSource;
import org.apache.commons.cli.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

public class Application {

    private static final Logger log = LoggerFactory.getLogger(Application.class);

    public static void main(String[] args) throws FileNotFoundException {
        Option optInputUrl = Option.builder().longOpt("input-url").desc("The remote URL to fetch RSS data from").required(false).hasArg().build();
        Option optInputFile = Option.builder().longOpt("input-file").desc("The remote URL to fetch RSS data from").required(false).hasArg().build();
        Option optOutputFile = Option.builder().longOpt("output-file").desc("The (optional) output file of the parse result").required(false).hasArg().build();

        Options options = new Options();
        options.addOption(optInputUrl);
        options.addOption(optInputFile);
        options.addOption(optOutputFile);

        CommandLine commandLine;
        try {
            commandLine = new DefaultParser().parse(options, args, false);
        } catch (ParseException ex) {
            log.error("Invalid arguments: " + ex.getMessage());
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("ant", options);
            return;
        }

        RssSource source = null;
        if (commandLine.hasOption(optInputUrl.getLongOpt())) {
            source = new RemoteSource(RssSource.Type.RSS_2_0, commandLine.getOptionValue(optInputUrl.getLongOpt()));
        } else if (commandLine.hasOption(optInputFile.getLongOpt())) {
            FileInputStream inputStream = new FileInputStream(new File(commandLine.getOptionValue(optInputFile.getLongOpt())));
            source = new LocalSource(RssSource.Type.RSS_2_0, inputStream);
        }
        Objects.requireNonNull(source, "Either input-url or input-file must be specified.");

        Optional<File> outputFile = Optional.empty();
        if (commandLine.hasOption(optOutputFile.getLongOpt())) {
            outputFile = Optional.of(new File(commandLine.getOptionValue(optOutputFile.getLongOpt())));
        }

        log.info("Configuring RSS engine ...");
        RssParseEngine engine = buildRssEngine(outputFile);
        log.info("Configured RSS parsers: {}", engine.getParsers().stream().map(e -> e.getClass().getName()).collect(Collectors.toList()));
        log.info("Configured RSS processors: {}", engine.getProcessors().stream().map(e -> e.getClass().getName()).collect(Collectors.toList()));

        log.info("Running RSS engine ...");
        long startTime = System.currentTimeMillis();
        engine.run(source);
        log.info("RSS engine finished in {} ms", System.currentTimeMillis() - startTime);
    }

    private static RssParseEngine buildRssEngine(Optional<File> outputFile) {
        List<RssParser> parsers = Arrays.asList(new NoopParser(), new Rss2Parser());
        List<RssProcessor> processors = new ArrayList<>();
        processors.add(new KeywordFilter());
        processors.add(new ConsoleWriter());
        outputFile.ifPresent(file -> processors.add(new CustomFileWriter(file)));
        return new RssParseEngine(parsers, processors);
    }

}
